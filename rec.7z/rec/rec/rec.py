import pandas
import numpy
import datetime
import os
import sys
import traceback

# define path
CurrentDirectory = os.getcwd()
InputDirectory = CurrentDirectory + '\\input\\'
OutputDirectory = CurrentDirectory + '\\output\\'

try:
    # read data
    old = pandas.read_csv(InputDirectory + 'old.csv', dtype = str) # na_values = 'N/A'
    new = pandas.read_csv(InputDirectory + 'new.csv', dtype = str)
    field = pandas.read_excel(InputDirectory + 'field.xlsx', header = None, squeeze = True).tolist()

    # data cleaning
    field = [x.upper() for x in field]
    old.columns = old.columns.str.upper()
    new.columns = new.columns.str.upper()

    old = old[field]
    new = new[field]

    for col in old.columns: old[col] = old[col].str.strip()
    for col in new.columns: new[col] = new[col].str.strip()

    # checking
    if len(old) != len(new):
        print('2 tables have different size. checking cannot be done')
        x = input('press any key to exit')
        import sys
        sys.exit()

    if any(old.duplicated()) == True:
        print('old dataset has duplicate records')

    if any(old.duplicated()) == True:
        print('old dataset has duplicate records')

    # del dup
    ##old['source'] = 'old'
    ##new['source'] = 'new'
    ##JoinTable = old.append(new).drop_duplicates(subset = field, keep = False)
    JoinTable = pandas.merge(old, new, on = field, how = 'outer', indicator = True)
    Inner = JoinTable.query("_merge=='both'")
    LeftOnly = JoinTable.query("_merge=='left_only'")
    RightOnly = JoinTable.query("_merge=='right_only'")

    # output file display
    Inner = Inner.drop(columns =['_merge'])
    LeftOnly = LeftOnly.drop(columns =['_merge'])
    RightOnly = RightOnly.drop(columns =['_merge'])
    LeftOnly['source'] = 'old'
    RightOnly['source'] = 'new'

    # output
    t = datetime.datetime.now().strftime("%Y.%m.%d %H.%M.%S")
    if LeftOnly.empty == False or RightOnly.empty == False:
    ##    LeftOnly.to_csv(OutputDirectory + 'records only exist in old dataset ' + t + '.csv', index = False)
    ##    RightOnly.to_csv(OutputDirectory + 'records only exist in new dataset ' + t + '.csv', index = False)
        LeftOnly.append(RightOnly).to_csv(OutputDirectory + t + '.csv', index = False)

except Exception as err:
   err_type = err.__class__.__name__ # 取得錯誤的class 名稱
   info = err.args[0] # 取得詳細內容
   detains = traceback.format_exc() # 取得完整的tracestack
   n1, n2, n3 = sys.exc_info() #取得Call Stack
   lastCallStack =  traceback.extract_tb(n3)[-1] # 取得Call Stack 最近一筆的內容
   fn = lastCallStack [0] # 取得發生事件的檔名
   lineNum = lastCallStack[1] # 取得發生事件的行數
   funcName = lastCallStack[2] # 取得發生事件的函數名稱
   errMesg = f"FileName: {fn}, lineNum: {lineNum}, Fun: {funcName}, reason: {info}, trace:\n {traceback.format_exc()}"
   print(errMesg)
   x = input('press any key to exit')
   import sys
   sys.exit()
